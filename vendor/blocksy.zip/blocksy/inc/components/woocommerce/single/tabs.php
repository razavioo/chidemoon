<?php

if ( !function_exists('blocksy_custom_accordion_tabs') ) {
	function blocksy_custom_accordion_tabs() {
		$is_open = blocksy_get_theme_mod('woo_accordion_closed_by_default', 'yes') === 'yes';
		$additional_attr = blocksy_get_theme_mod('woo_accordion_close_prev', 'yes') === 'yes' ? 'data-close-others' : '';

		$tabs = apply_filters( 'woocommerce_product_tabs', [] );
		$index = 0;

		if ( ! empty( $tabs ) ) : ?>
			<div class="woocommerce-tabs wc-tabs-wrapper">

				<?php foreach ( $tabs as $key => $tab ) : ?>
					<div class="ct-accordion-tab">
						<button
							class="ct-accordion-heading ct-expandable-trigger is-width-constrained"
							data-target="#tab-<?php echo esc_attr( $key ); ?>"
							aria-expanded="<?php echo $is_open && !$index ? "true" : "false" ?>"
							<?php echo $additional_attr; ?>
							>
							<?php echo wp_kses_post( apply_filters( 'woocommerce_product_' . $key . '_tab_title', $tab['title'], $key ) ); ?>

							<svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor">
								<path d="M10,20c-0.6,0-1-0.4-1-1V1c0-0.6,0.4-1,1-1s1,0.4,1,1v18C11,19.6,10.6,20,10,20z"/>
								<path d="M19,11H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h18c0.6,0,1,0.4,1,1S19.6,11,19,11z"/>
							</svg>
						</button>

						<article id="tab-<?php echo esc_attr( $key ); ?>" aria-hidden="<?php echo $is_open && !$index ? "false" : "true" ?>" data-behaviour="drop-down">
							<div class="entry-content is-layout-constrained">
								<?php
									if (isset($tab['callback'])) {
										call_user_func( $tab['callback'], $key, $tab );
									}
								?>
							</div>
						</article>
					</div>
				<?php
					$index++;
					endforeach;
				?>

			</div>
		<?php endif;
	}
}

if ( !function_exists('blocksy_custom_simple_tabs') ) {
	function blocksy_custom_simple_tabs() {
		$tabs = apply_filters( 'woocommerce_product_tabs', [] );

		if ( ! empty( $tabs ) ) : ?>
			<div class="woocommerce-tabs wc-tabs-wrapper">
				<article>
					<?php foreach ( $tabs as $key => $tab ) : ?>
						<div id="tab-<?php echo esc_attr( $key ); ?>" class="entry-content is-layout-constrained">
							<?php
							ob_start();
							call_user_func( $tab['callback'], $key, $tab );
							$tab_content = ob_get_clean();
							$tab_title = apply_filters( 'woocommerce_product_' . $key . '_tab_title', $tab['title'], $key );

							preg_match_all( '/<h2\\b[^>]*>(.*?)<\\/h2>/is', $tab_content, $tab_heading_matches );
							$tab_headings = array_map( 'trim', array_map( 'wp_strip_all_tags', $tab_heading_matches[1] ) );
							$has_title = in_array( trim( wp_strip_all_tags( $tab_title ) ), $tab_headings, true );

							if ( ! $has_title ) {
								echo '<h2>' . wp_kses_post( $tab_title ) . '</h2>';
							}

							// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							echo $tab_content;
							?>
						</div>
					<?php endforeach; ?>
				</article>
			</div>
		<?php endif;
	}
}

if (! function_exists('woocommerce_output_product_data_tabs')) {
	function woocommerce_output_product_data_tabs()  {
		if (! blocksy_manager()->screen->uses_woo_default_template()) {
			wc_get_template( 'single-product/tabs/tabs.php' );
			return;
		}
		$result = '';
		$res = blocksy_get_theme_mod('woo_tabs_type', 'type-1');

		if (
			$res === 'type-1'
			||
			$res === 'type-2'
		) {
			ob_start();
			wc_get_template( 'single-product/tabs/tabs.php' );
			$result = ob_get_clean();
		}

		if ($res === 'type-3') {
			if (blocksy_get_theme_mod('woo_accordion_in_summary', 'default') === 'summary') {
				return;
			}
			ob_start();
			blocksy_custom_accordion_tabs();
			$result = ob_get_clean();
		}

		if ( $res === 'type-4' ) {
			if (blocksy_get_theme_mod('woo_accordion_in_summary', 'default') === 'summary') {
				return;
			}
			ob_start();
			blocksy_custom_simple_tabs();
			$result = ob_get_clean();
		}

		$res .= ':' . blocksy_get_theme_mod('woo_tabs_alignment', 'center');

		$prefix = blocksy_manager()->screen->get_prefix();

		$deep_link_args = [
			'prefix' => $prefix,
			'suffix' => 'woo_has_product_tabs'
		];

		$result = str_replace(
			'"tabs wc-tabs',
			'"tabs wc-tabs is-width-constrained',
			$result
		);

		echo str_replace(
			'wc-tabs-wrapper"',
			'wc-tabs-wrapper" data-type="' . $res . '" ' . blocksy_generic_get_deep_link($deep_link_args),
			$result
		);
	}
}
